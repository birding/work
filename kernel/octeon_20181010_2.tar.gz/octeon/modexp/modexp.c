#include <linux/module.h>
#include <linux/slab.h>
#include <linux/platform_device.h>
#include <asm/octeon/cvmx-asm.h>
#include <asm/octeon/cvmx-pko3.h>

//#define DEBUG_printk printk
#define DEBUG_printk(...)   do { } while(0)

#define BN_ULONG	unsigned long
#define CVMX_VMULU(dest,mpcand,accum) asm volatile ("vmulu %[rd],%[rs],%[rt]" : [rd] "=d" (dest) : [rs] "d" (mpcand), [rt] "d" (accum))

struct bignum_st
	{
	BN_ULONG *d;	/* Pointer to an array of 'BN_BITS2' bit chunks. */
	int top;	/* Index of last used d +1. */
	/* The next are internal book keeping for bn_expand. */
	int dmax;	/* Size of the d array. */
	int neg;	/* one if the number is negative */
	int flags;
	};

typedef struct bignum_st BIGNUM;

#define BN_CTX_POOL_SIZE 16

typedef struct bignum_pool_item
	{
	/* The bignum values */
	BIGNUM vals[BN_CTX_POOL_SIZE];
	/* Linked-list admin */
	struct bignum_pool_item *prev, *next;
	} BN_POOL_ITEM;

typedef struct bignum_pool
	{
	/* Linked-list admin */
	BN_POOL_ITEM *head, *current_yisp, *tail;
	/* Stack depth and allocation size */
	unsigned used, size;
	} BN_POOL;

typedef struct bignum_ctx_stack
	{
	/* Array of indexes into the bignum stack */
	unsigned int *indexes;
	/* Number of stack frames, and the size of the allocated array */
	unsigned int depth, size;
	} BN_STACK;

/* The opaque BN_CTX type */
struct bignum_ctx
	{
	/* The bignum bundles */
	BN_POOL pool;
	/* The "stack frames", if you will */
	BN_STACK stack;
	/* The number of bignums currently assigned */
	unsigned int used;
	/* Depth of stack overflow */
	int err_stack;
	/* Block "gets" until an "end" (compatibility behaviour) */
	int too_many;
	};
typedef struct bignum_ctx BN_CTX;

#define ROUNDUP8(val) (((val) + 7)&0xfffffff8)
#define ROUNDUP2(v)	((((v) + 1) / 2) * 2)


int MontMul512(uint64_t * product, uint64_t * mpcand, uint64_t * mplier,
  uint64_t * mod, uint64_t * recip);
int MontMul_O3(uint64_t * product, uint64_t * mpcand, uint64_t * mplier,
  uint64_t * mod, uint64_t * recip, int len);

extern int Vsub(uint64_t * accum, uint64_t * addend, int len);

#define MUL_PAD  8 

#define bn_wexpand(a,words) (((words) <= (a)->dmax)?(a):bn_expand2((a),(words)))

#define bn_check_top(a)
#define BN_BITS2	64
#define BNerr(f,r) printk("error")

#define ERR_R_FATAL				64
#define	ERR_R_MALLOC_FAILURE			(1|ERR_R_FATAL)

#define BN_F_BN_EXPAND_INTERNAL				 120
#define BN_R_EXPAND_ON_STATIC_BIGNUM_DATA		 105
#define BN_R_BIGNUM_TOO_LONG				 114

#define BN_FLG_STATIC_DATA	0x02
#define BN_get_flags(b,n)	((b)->flags&(n))


static int poolSelect=0;
static int auraId=1021;
static int debuglevel=0;
extern struct kmem_cache *modexp_cache;
void set_memPoolSelection(int select, int id, int debug)
{
	poolSelect= select;
	auraId=id;
	debuglevel=debug;
}

void * mem_alloc(int size)
{
	void * ptr=NULL;

	if(poolSelect ==0){
		ptr = kmalloc(size, GFP_ATOMIC);
		if (!ptr) {
			printk("[%s][%d]No memory for size %d poolSelect %d\n", __func__, __LINE__, size, poolSelect);
		}
	}else if(poolSelect ==1){
		ptr = kmalloc(size, GFP_KERNEL);
		if (!ptr) {
			printk("[%s][%d]No memory for size %d poolSelect %d\n", __func__, __LINE__, size, poolSelect);
		}	
	}else if(poolSelect ==2){
		ptr = octeon_fpa3_alloc(0, auraId);
		if (!ptr) {
			printk("[%s][%d]No memory for size %d poolSelect %d\n", __func__, __LINE__, size, poolSelect);
		}		
	}else if(poolSelect ==3){
		if (modexp_cache) {
			ptr = kmem_cache_alloc(modexp_cache, GFP_KERNEL);
			if (!ptr) {
				printk("[%s][%d]No memory for size %d poolSelect %d\n", __func__, __LINE__, size, poolSelect);
			}	
		}else{
			printk("[%s][%d]No modexp_cache for size %d poolSelect %d\n", __func__, __LINE__, size, poolSelect);
		}
	}else{
		ptr = kmalloc(size, GFP_ATOMIC);
		if (!ptr) {
			printk("[%s][%d]No memory for size %d poolSelect %d\n", __func__, __LINE__, size, poolSelect);
		}
	}
	return ptr;
}

void mem_free(void * mptr)
{
	if (!mptr) {
		printk("[%s][%d]Free NULL pointer \n", __func__, __LINE__);
		return ;
	}
	
	if(poolSelect ==0){
		kfree(mptr);	
	}else if(poolSelect ==1){
		kfree(mptr);
	}else if(poolSelect ==2){
		octeon_fpa3_free(0, auraId, mptr);
	}else if(poolSelect ==3){
		kfree(mptr);
	}else{
		kfree(mptr);
	}	
	return ;
}

/* This is used both by bn_expand2() and bn_dup_expand() */
/* The caller MUST check that words > b->dmax before calling this */
static BN_ULONG *bn_expand_internal(const BIGNUM *b, int words)
	{
	BN_ULONG *A,*a = NULL;
	const BN_ULONG *B;
	int i;

	bn_check_top(b);

	if (words > (INT_MAX/(4*BN_BITS2)))
	{
		BNerr(BN_F_BN_EXPAND_INTERNAL,BN_R_BIGNUM_TOO_LONG);
		return NULL;
	}
	if (BN_get_flags(b,BN_FLG_STATIC_DATA))
	{
		BNerr(BN_F_BN_EXPAND_INTERNAL,BN_R_EXPAND_ON_STATIC_BIGNUM_DATA);
		return(NULL);
	}
	a=A=(BN_ULONG *)mem_alloc(sizeof(BN_ULONG)*words);
	if (A == NULL)
	{
		BNerr(BN_F_BN_EXPAND_INTERNAL,ERR_R_MALLOC_FAILURE);
		return(NULL);
	}
#if 1
	B=b->d;
	/* Check if the previous number needs to be copied */
	if (B != NULL)
	{
		for (i=b->top>>2; i>0; i--,A+=4,B+=4)
		{
			/*
			 * The fact that the loop is unrolled
			 * 4-wise is a tribute to Intel. It's
			 * the one that doesn't have enough
			 * registers to accomodate more data.
			 * I'd unroll it 8-wise otherwise:-)
			 *
			 *		<appro@fy.chalmers.se>
			 */
			BN_ULONG a0,a1,a2,a3;
			a0=B[0]; a1=B[1]; a2=B[2]; a3=B[3];
			A[0]=a0; A[1]=a1; A[2]=a2; A[3]=a3;
		}
		switch (b->top&3)
		{
		case 3:	A[2]=B[2];
		case 2:	A[1]=B[1];
		case 1:	A[0]=B[0];
		case 0: /* workaround for ultrix cc: without 'case 0', the optimizer does
		         * the switch table by doing a=top&3; a--; goto jump_table[a];
		         * which fails for top== 0 */
			;
		}
	}

#else
	memset(A,0,sizeof(BN_ULONG)*words);
	memcpy(A,b->d,sizeof(b->d[0])*b->top);
#endif
		
	return(a);
}

BIGNUM *bn_expand2(BIGNUM *b, int words)
{
	bn_check_top(b);

	if (words > b->dmax)
	{
		BN_ULONG *a = bn_expand_internal(b, words);
		if(!a) return NULL;
		if(b->d) mem_free(b->d);
		b->d=a;
		b->dmax=words;
	}

/* None of this should be necessary because of what b->top means! */
#if 0
	/* NB: bn_wexpand() calls this only if the BIGNUM really has to grow */
	if (b->top < b->dmax)
		{
		int i;
		BN_ULONG *A = &(b->d[b->top]);
		for (i=(b->dmax - b->top)>>3; i>0; i--,A+=8)
			{
			A[0]=0; A[1]=0; A[2]=0; A[3]=0;
			A[4]=0; A[5]=0; A[6]=0; A[7]=0;
			}
		for (i=(b->dmax - b->top)&7; i>0; i--,A++)
			A[0]=0;
		assert(A == &(b->d[b->dmax]));
		}
#endif
	bn_check_top(b);
	return b;
	}

#define SPEEDUP_CODE 1
#define _MIPS_ARCH_OCTEON3 1


#define MAX_BUF_SIZE				(256)
void
overlap_move(void *buf, size_t len)
{
    uint64_t *b = (uint64_t *)buf;
    register uint64_t t0, t1;
    size_t i;

    t0 = *b;
    t1 = *(b + 1);

    for(i = 0; i < (len - 2); i++)
    {
        *(b + i + 1) = t0;
        t0 = t1;
        t1 = *(b + i + 2);
    }

    *(b + i + 1) = t0;
    *(b + i + 2) = t1;
}

#define ZERO_CACHE_BLOCK(b)				\
	asm volatile("zcb (%[rs])" : : [rs] "d" (b))
int
zero_cache_lines(void *addr, int n_cache_lines)
{
    int i;
    unsigned char *base = (unsigned char *)addr;

    for(i = 0; i < n_cache_lines; i++)
        ZERO_CACHE_BLOCK((base + (128 * i)));

    return 1;
}

#define FATAL_ERROR 

struct test_buff {
	uint64_t mem[128 + 8];
};

void
MMLoop_O3(uint64_t *product, const uint64_t *base, const uint64_t *exponent,
    const uint64_t *mod, const uint64_t *recip, int len, int elen)
{
    uint64_t *temp;

    int i, size, bits, psize;
    int lenx8 = len * sizeof(uint64_t);
    //uint64_t precompute[16][128 + 8];//8*16*136=17408
	uint64_t * precompute[16];
	
    size = sizeof(uint64_t) * (len + 6);//size=8*(32+6)=304

    if((temp = mem_alloc(size)) == NULL)
    {
        printk("[%s][%d]memory allocation failed\n", __func__, __LINE__);
        return;
    }

	for(i=0;i<16;i++){
		if((precompute[i] = mem_alloc(sizeof(struct test_buff))) == NULL)
	    	{
	        printk("[%s][%d]memory allocation failed\n", __func__, __LINE__);
	        return;
	    	}
	}
	
    memset(temp, 0, size);

    psize = (int)sizeof(precompute[0]);
    memset(precompute[0], 0, psize);
    memset(precompute[1], 0, psize);

    memcpy(precompute[0], product, size);
    memcpy(precompute[1], base, size);

    for(i = 2; i < 16; i++)
    {
#ifdef SPEEDUP_CODE
        if(len <= 8)
            MontMul512((uint64_t *)precompute[i], (uint64_t *)precompute[i - 1],
                (uint64_t *)base, (uint64_t *)mod, (uint64_t *)recip);
        else
            MontMul_O3((uint64_t *)precompute[i], (uint64_t *)precompute[i - 1],
                (uint64_t *)base, (uint64_t *)mod, (uint64_t *)recip, len);
#else
#ifdef STACK_VARIABLE_ALLOC
        //memset(precompute[i], 0, psize);
#endif
        memcpy(temp, precompute[i - 1], lenx8);

        if(len <= 8)
        {
            MontMul512((uint64_t *)precompute[i], (uint64_t *)temp,
                (uint64_t *)base, (uint64_t *)mod, (uint64_t *)recip);
        }
        else
        {
            MontMul_O3((uint64_t *)precompute[i], (uint64_t *)temp,
                (uint64_t *)base, (uint64_t *)mod, (uint64_t *)recip, len);
        }
#endif
    }

    for(i = (len * 16) - 1; i >= 0; i--)
    {
        bits = ((exponent[i / 16] >> ((i & 15) << 2)) & 0xf);

        if(bits) break;
    }

    for(; i >= 0; i--)
    {
        bits = (exponent[i / 16] >> ((i & 15) << 2)) & 0xf;

        if(len <= 8)
        {
            MontMul512((uint64_t *)temp, (uint64_t *)product,
                (uint64_t *)product, (uint64_t *)mod, (uint64_t *)recip);

            MontMul512((uint64_t *)product, (uint64_t *)temp,
                (uint64_t *)temp, (uint64_t *)mod, (uint64_t *)recip);

            MontMul512((uint64_t *)temp,(uint64_t *)product,
                (uint64_t *)product, (uint64_t *)mod, (uint64_t *)recip);

            MontMul512((uint64_t *)product, (uint64_t *)temp,
                (uint64_t *)temp, (uint64_t *)mod, (uint64_t *)recip);

        }
        else
        {
            MontMul_O3((uint64_t *)temp, (uint64_t *)product,
                (uint64_t *)product, (uint64_t *)mod, (uint64_t *)recip, len);

            MontMul_O3((uint64_t *)product, (uint64_t *)temp,
                (uint64_t *)temp, (uint64_t *)mod,(uint64_t *)recip, len);

            MontMul_O3((uint64_t *)temp, (uint64_t *)product,
                (uint64_t *)product, (uint64_t *)mod, (uint64_t *)recip, len);

            MontMul_O3((uint64_t *)product, (uint64_t *)temp,
                (uint64_t *)temp, (uint64_t *)mod, (uint64_t *)recip, len);
        }

        if(len <= 8)
        {
            MontMul512((uint64_t *)temp, (uint64_t *)product,
                (uint64_t *)precompute[bits], (uint64_t *)mod,
                (uint64_t *)recip);
        }
        else
        {
            MontMul_O3((uint64_t *)temp, (uint64_t *)product,
                (uint64_t *)precompute[bits], (uint64_t *)mod,
                (uint64_t *)recip, len);
        }

        memcpy(product, temp, lenx8);
    }

    if(temp) mem_free(temp);
	for(i=0;i<16;i++){
		if(precompute[i]) mem_free(precompute[i]);
	}
}

static int
_cvm_ModExp_octeon3(uint64_t *product, uint64_t *base, uint64_t *exponent,
    uint64_t *mod, int len, int elen, int mlen, int blen, int convert)
{
    int success = 0;
#if !defined(TARGET_LINUX) || defined(USER_SPACE_MODEXP)
    if(1)
#else
    if(!cvm_crypto_vmul_hwbug())
#endif
    {
        uint64_t recip[6];
        // first compute montgomery reciprocal
        int i, size;
        int lenx8;
        int msw = 0;
        uint64_t junk = 0;
        int normalize, r; 
        uint64_t *residue = NULL, *temp = NULL,
                  *negmod = NULL, *temp_base = NULL;


        lenx8 = sizeof(uint64_t) * len; //lenx8 = 8*32
        len   = (len + 3) & 0xfffc;  //len = 32
        size  = sizeof(uint64_t) * (len + 6); //size = 8*(32+6) = 304


        /* Moved the memory from stack to heap */
        residue   = (uint64_t *)mem_alloc(size);
        temp      = (uint64_t *)mem_alloc(size);
        negmod    = (uint64_t *)mem_alloc(size);
        temp_base = (uint64_t *)mem_alloc(size);

        if(!temp || !negmod || !residue || !temp_base)
        {
            printk("memory allocation failed\n");
            goto err;
        }

        memset(residue,   0, size);
        memset(temp,      0, size);
        memset(negmod,    0, size);
        memset(temp_base, 0, size);
        memset(recip,     0, sizeof(recip));

        for(i = 0; i < len; i++)
        {
            negmod[i] = 0;
            if(mod[i] != 0) break;
        }

        negmod[i] = ~mod[i] + 1;

        for(i++; i < len; i++)
            negmod[i] = ~mod[i];

        negmod[len] = ~(uint64_t)0;

        /* I need to know where most significant word of the modulus is */
        for(msw = len - 1; msw >= 0; msw--)
            if(mod[msw])
                break;

        normalize = mod[msw] < ((uint64_t)1 << 32);

        if(normalize)
        {
            for(i = msw; i >= 1; i--)
                negmod[i] = (negmod[i] << 32) | (negmod[i - 1] >> 32);

            negmod[0] = (negmod[0] << 32);
        }

        recip[0] = 0;
        recip[1] = 0;

        junk = 0;
        CVMX_MTM2_V3(0, 0);

        for(i = 63; i >= 0; i--)
        {
            recip[1] |= (uint64_t)1 << i;

            CVMX_MTM0_V3(recip[0], 0);
            CVMX_MTM1_V3(recip[1], 0);

            CVMX_VMULU(junk, negmod[msw - 1], 0);
            CVMX_VMULU(junk, negmod[msw], 0);
            CVMX_VMULU(junk, (int64_t)-1, 0);
            CVMX_VMULU(junk, (int64_t)-1, (uint64_t)1 << 32);

            if((junk >> 63))
                recip[1] ^= (uint64_t)1 << i;
        }

        junk = 0;

        for(i = 63; i >= 0; i--)
        {
            recip[0] |= (uint64_t)1 << i;

            CVMX_MTM0_V3(recip[0], 0);
            CVMX_MTM1_V3(recip[1], 0);

            CVMX_VMULU(junk, negmod[msw - 1], 0);
            CVMX_VMULU(junk, negmod[msw], 0);
            CVMX_VMULU(junk, (int64_t)-1, 0);
            CVMX_VMULU(junk, (int64_t)-1, (uint64_t)1 << 32);

            if((junk >> 63))
                recip[0] ^= (uint64_t)1 << i;
        }

        r = (len <= 8) ? 8 : ((len + 5) / 6) * 6;
        r = r * 2;

        residue[msw] = (normalize ? ((uint64_t)1 << 32) : 1);
        r -= msw;


        /* Each iteration I'll left shift things 64 bits and do
         * a modular reduction.
         */
        for(i = 0; i < r; i++)
        {
            int k;
            uint64_t q[4] = {0, 0, 0, 0};
#ifdef SPEEDUP_CODE
            overlap_move(residue, len);
#else
            memmove(residue + 1, residue, lenx8);
#endif
            residue[0] = 0;

            CVMX_MTM0_V3(recip[0], 0);
            CVMX_MTM1_V3(recip[1], 0);
            CVMX_MTM2_V3(0, 0);

            CVMX_VMULU(q[0], (residue[msw] >> 32) | (residue[msw + 1] << 32), 0);
            CVMX_VMULU(q[1], (residue[msw + 1] >> 32), 0);
            CVMX_VMULU(q[2], 0, 0);
            CVMX_VMULU(q[3], 0, 0);

            CVMX_MTM0_V3(q[2], 0);
            CVMX_MTM1_V3(q[3], 0);
            CVMX_MTM2_V3(0, 0);

#ifdef SPEEDUP_CODE
            {
                uint64_t n0, n1, r0, r1;

                CVMX_MTM2_V3(0, 0);

                n0 = negmod[0];
                r0 = residue[0];
                n1 = negmod[1];
                r1 = residue[1];

                CVMX_V3MULU(r0, n0, r0);

                for(k = 1; k < len; k++)
                {
                    residue[k - 1] = r0;
                    CVMX_V3MULU(r0, n1, r1);
                    n1 = negmod[k + 1];
                    r1 = residue[k + 1];
                }

                residue[len - 1] = r0;

                CVMX_V3MULU(r0, n1, r1);

                residue[len] = r0;
            }
#else
            for(k = 0; k < len + 1; k++)
                CVMX_VMULU(residue[k], negmod[k], residue[k]);
#endif

            if(residue[len] > 1)
             {
                 FATAL_ERROR;
             }
        }

        if(normalize)
        {
            if(residue[0] << 32)
            {
                FATAL_ERROR;
            }

            for(i = 0; i < len; i++)
                residue[i] = (residue[i] >> 32) | (residue[i + 1] << 32);

            residue[len] = 0;
        }

        if(len <= 8)
        {
            recip[0] = 0;
            recip[1] = 0;

            CVMX_MTM2_V3(0, 0);

#if defined(USER_SPACE_MODEXP)
            CVMX_MTM0_V3(0, 0);
            CVMX_MTM1_V3(0, 0);
            CVMX_MTM2_V3(0, 0);
#endif

            for(i = 0; i < 128; i++)
            {
                uint64_t *sub = &recip[i / 64];
                int k;
                char undo = 0;
                uint64_t p[2];
                *sub |= (uint64_t)1 << (i & 63);

                CVMX_MTM0_V3(recip[0], 0);
                CVMX_MTM1_V3(recip[1], 0);

#if !defined(USER_SPACE_MODEXP)
                CVMX_VMULU(p[0], mod[0], 1);
                CVMX_VMULU(p[1], mod[1], 0);
#else
                CVMX_MTM2_V3(0, 0);
                CVMX_V3MULU(p[0], mod[0], 1);
                CVMX_V3MULU(p[1], mod[1], 0);
#endif

                for(k = 0; k < (i / 64); k++)
                    undo = undo || p[k];

                undo = undo || (p[i / 64] << (63 - (i & 63)));

                if(undo)
                    *sub ^= (uint64_t)1 << (i & 63);
            }
        }
        else
        {
            for(i = 0; i < 6; i++)
                recip[i] = (uint64_t)0;

            for(i = 0; i < 384; i++)
            {
                uint64_t *sub = &recip[i / 64];
                int k;
                char undo = 0;
                uint64_t p[6];

                *sub |= ((uint64_t)1 << (i & 63));

                CVMX_MTM0_V3(recip[0], recip[3]);
                CVMX_MTM1_V3(recip[1], recip[4]);
                CVMX_MTM2_V3(recip[2], recip[5]);

                CVMX_V3MULU(p[0], mod[0], 1);
                CVMX_V3MULU(p[1], mod[1], 0);
                CVMX_V3MULU(p[2], mod[2], 0);
                CVMX_V3MULU(p[3], mod[3], 0);
                CVMX_V3MULU(p[4], mod[4], 0);
                CVMX_V3MULU(p[5], mod[5], 0);

                for(k = 0; k < (i / 64); k++)
                    undo = undo || p[k];

                undo = undo || (p[i / 64] << (63 - (i & 63)));

                if(undo)
                    *sub ^= ((uint64_t)1 << (i & 63));
            }
        }

        if(len <= 8)
        {
            MontMul512((uint64_t *)product, (uint64_t *)base,
                (uint64_t *)residue, (uint64_t *)mod, (uint64_t *)recip);
        }
        else
        {
            MontMul_O3((uint64_t *)product, (uint64_t *)base,
                (uint64_t *)residue, (uint64_t *)mod, (uint64_t *)recip, len);
        }

        memcpy(temp_base, product, lenx8);

#if 0
#ifdef SPEEDUP_CODE
        zero_cache_lines(temp, cache_lines);
#else
        memset(temp, 0, size);
#endif
#endif

        temp[0] = 1;

        if(len <= 8)
        {
            MontMul512((uint64_t *)product, (uint64_t *)temp,
                (uint64_t *)residue, (uint64_t *)mod, (uint64_t *)recip);
        }
        else
        {
            MontMul_O3((uint64_t *)product, (uint64_t *)temp,
                (uint64_t *)residue, (uint64_t *)mod, (uint64_t *)recip, len);
        }

        MMLoop_O3(product, temp_base, exponent, mod, recip, len, elen);
        memset(residue, 0, size);

        residue[0] = 1;
        memset(temp, 0, size);

        if(len <= 8)
        {
            MontMul512((uint64_t *)temp, (uint64_t *)product,
                (uint64_t *)residue, (uint64_t *)mod, (uint64_t *)recip);
        }
        else
        {
            MontMul_O3((uint64_t *)temp, (uint64_t *)product,
                (uint64_t *)residue, (uint64_t *)mod, (uint64_t *)recip, len);
        }

        memcpy(product, temp, lenx8);

        Vsub(temp, mod, len + 1);

        if(!(temp[len] >> 63))
            memcpy(product, temp, lenx8);

        success = 1;

err:
        if(residue)    mem_free(residue);
        if(temp)       mem_free(temp);
        if(negmod)     mem_free(negmod);
        if(temp_base)  mem_free(temp_base);
    }
    return success;

}

static int
_cvm_ModExp(uint64_t * product, uint64_t * base, uint64_t * exponent,
    uint64_t * mod, int len, int elen, int mlen, int blen, int convert)
{
            return _cvm_ModExp_octeon3(product, base, exponent, mod,
                            len, elen, mlen, blen, convert);
}

int
cav_mod_exp(BIGNUM * res, const BIGNUM * base, const BIGNUM * exp,
            const BIGNUM * mod, BN_CTX * ctx)
{
  uint8_t *copy_base = NULL;
  uint8_t *copy_exp = NULL;
  uint8_t *copy_mod = NULL;
  int ret = 0;                  //BN_mod_exp returns 1 on success and 0 on error
  int mlen, elen, blen;
  int len;

  copy_base = (uint8_t *)mem_alloc((ROUNDUP2(mod->top) + MUL_PAD) * 8);
  copy_exp  = (uint8_t *)mem_alloc((ROUNDUP2(mod->top) + MUL_PAD) * 8);
  copy_mod  = (uint8_t *)mem_alloc((ROUNDUP2(mod->top) + MUL_PAD) * 8);

  if (copy_base == NULL || copy_exp == NULL || copy_mod == NULL) {
  	printk("[%s][%d]No memory\n", __func__, __LINE__);
  	 goto modexp_err;
  }
  memset(copy_base, 0, (ROUNDUP2(mod->top) + MUL_PAD) * 8);
  memset(copy_exp,  0, (ROUNDUP2(mod->top) + MUL_PAD) * 8);
  memset(copy_mod,  0, (ROUNDUP2(mod->top) + MUL_PAD) * 8);

  memcpy(copy_exp,  exp->d,  exp->top  * sizeof (BN_ULONG));
  memcpy(copy_mod,  mod->d,  mod->top  * sizeof (BN_ULONG));
  memcpy(copy_base, base->d, base->top * sizeof (BN_ULONG));

  if (bn_wexpand(res, ROUNDUP2(mod->dmax) + MUL_PAD) == NULL){
	printk("[%s][%d]error \n", __func__, __LINE__);
	goto modexp_err;
  }
  memset(res->d, 0, (ROUNDUP2(mod->dmax) + MUL_PAD) * sizeof(BN_ULONG));

  mlen = ROUNDUP8(mod->top  * sizeof (BN_ULONG));
  elen = ROUNDUP8(exp->top  * sizeof (BN_ULONG));
  blen = ROUNDUP8(base->top * sizeof (BN_ULONG));
  len  = ((((mod->top * sizeof(BN_ULONG)) * 8) + 63) / 64);

  _cvm_ModExp((uint64_t *)res->d, (uint64_t *)copy_base,
    (uint64_t *)copy_exp, (uint64_t *)copy_mod,
    len, elen, mlen, blen, 1);

  res->top = mod->top;
  ret = 1;                      // Success
modexp_err:
  if (copy_base)
    mem_free(copy_base);
  if (copy_exp)
    mem_free (copy_exp);
  if (copy_mod)
    mem_free (copy_mod);
  return ret;
}

#define UCHAR unsigned char
int initParam(BIGNUM * ga, BIGNUM * gp, BIGNUM * gm, BIGNUM * grr)
{
	UCHAR * paraA ="3588FCC221749B1D3632BC7DC2979E5FB12948359107E1310ED04921409F6D289582BAEC48A8F057A8E4C98392AC60DF87350AD39C48E5191CF9F495F00EECAD9258455DD5FB2D8500F8E403E90C4F1DFADD9909C9EA8D7EEB0C002707BBF9D865C7F0AA69FA0DF878DFEE6AE31EFA9DCFCE6288341003606A1890661EB674FD751BC5F2F5DC181C34DA883EE57DC88B0C7E2C8A90D263DBE1EC1172848C57E1BFF7820DF52D571A403B665B4567EE37F59CA5156193297F40FA14CDA1CE5409A4FFB20239112F15BF2AFA7E55A6ABB0F54634EBB3202F2435DEBE22258F38834C4383FF3487A62B407A7BD8F4732FEFBE426AA5E7540D102F2C1F95EC565FB4";
	UCHAR * paraP = "C4C7095DDA7AA341D2B8424C4402454710F1F0DD99D9321B3CC46A2E5930C22ED09510FB3B4CBCEC536226A27FD418D9D002434A44C37273CC4608565A294641DC5DD00ECAA938BBCD2396F8FEC4019C07F76A3F816BC200BBDAE10AD4EE889F806ABB9EFAC5E4CB73C2F9DEB8E9EA2036072029DDCA4A690B96AF9F95B95C09FD5D511C4723265A2DDBFDA95BF7B28A2390CA5B8EDEFDAB2E57B6F998AAEB97556D1A90D73D81B567EBF80F4A20400821395F4E13D61F4A4CFE12C374897A5FAE187C5AB5E6974141FA232E5E509B8B175D8D59C5F0DF5F728641BF08D5E1510716DA5BAEE922CB9C40008FE2DBEA93430679D66E8877061E6FE940B0EA79D8";
	UCHAR * paraM = "71F368A5CEAE923348981A8ED103376ECB25BA18604076261CD2ECFD133FD76BE695C4DA5B803D0F84F23C03E95DE3BCA263E56F202557C3DF0EEFB7A573BC8C397761631B1DFC50058580F2D5FC7F9EF3425DDB6FD0126665FC1619E485DB24529FBFCA0570FA570660F8477219B5191421BE6386ADC6967C3524D1D01120F650C620AC429D370F01E5AAA857E088C7053EA4A2FFC1F8E5771843B34464ED91C95671134A2E4D33D2E2189400CA21E7115C30F4226914DB8536E5B20D9DDB9B264F0775C1EFCE3934311E085B7CBDEC7DFF466CA42FBEDDB59005329ECDDC047945F81A2F19C435EBEB61641292A9A473A657D0C2EDB962DF67013158D38DBD";
	UCHAR * result = "A22CD774E196759ED79FA5B2F0638858B147E30A4E1FD0CAA4F82C6852368137FED3BB86534C960BF24B82C86B8B067C7241A51FC57958A1ABF08554719259CD089C93CA363F0BA16E36466D8E6D2AC3DB546874A8365698980851ADC023D814F1A5C9FC541728C0B3D31EE89C49C5A1B91CE9BD33B39755E01EC99F319F440B5234BB81CEBC58EAC301C62F7AB4174A1816999FB26BE082E0AC92BCB007D988D437DD8BCC76B9344C49768098034101F0B983A938CD59FF2852DEB9FA1EA5AF0AC8023FD4A6EED5D927CD5632120828F5535005D675C312823DEABD02C2FFBE969D897E12D8CEDF3CD09BA64FF36B3F6BB2BA7E59F9A0A7BF6DFB5D6F1BF8FD";
	long l,k;
	int m,n;
	void * ptr=NULL;
		
	ga->top = 32;
	ga->dmax = 32;
	ga->neg = 0;
	ga->flags = 0;
	ptr= mem_alloc(256);
	if (!ptr) {
		printk("[%s][%d]No memory\n", __func__, __LINE__);
		return -1;
	}
	ga->d = (BN_ULONG *)ptr;
	k=0;
	for(l=0; l<512; l+=2){
		m=(paraA[l] < 'A')?(paraA[l] - '0'):(paraA[l] - 'A' + 10);
		n=(paraA[l+1] < 'A')?(paraA[l+1] - '0'):(paraA[l+1] - 'A' + 10)	;
		((UCHAR *)ga->d)[k] = m*16+n;
		k++;
	}

	gp->top = 32;
	gp->dmax = 32;
	gp->neg = 0;
	gp->flags = 0;
	ptr= mem_alloc(256);
	if (!ptr) {
		printk("[%s][%d]No memory\n", __func__, __LINE__);
		return -1;
	}
	gp->d = (BN_ULONG *)ptr;
	k=0;
	for(l=0; l<512; l+=2){
		m=(paraP[l] < 'A')?(paraP[l] - '0'):(paraP[l] - 'A' + 10);
		n=(paraP[l+1] < 'A')?(paraP[l+1] - '0'):(paraP[l+1] - 'A' + 10)	;
		((UCHAR *)gp->d)[k] = m*16+n;
		k++;
	}

	gm->top = 32;
	gm->dmax = 32;
	gm->neg = 0;
	gm->flags = 0;
	ptr= mem_alloc(256);
	if (!ptr) {
		printk("[%s][%d]No memory\n", __func__, __LINE__);
		return -1;
	}
	gm->d = (BN_ULONG *)ptr;
	k=0;
	for(l=0; l<512; l+=2){
		m=(paraM[l] < 'A')?(paraM[l] - '0'):(paraM[l] - 'A' + 10);
		n=(paraM[l+1] < 'A')?(paraM[l+1] - '0'):(paraM[l+1] - 'A' + 10)	;
		((UCHAR *)gm->d)[k] = m*16+n;
		k++;
	}

	grr->top = 32;
	grr->dmax = 32;
	grr->neg = 0;
	grr->flags = 0;
	ptr= mem_alloc(256);
	if (!ptr) {
		printk("[%s][%d]No memory\n", __func__, __LINE__);
		return -1;
	}
	grr->d = (BN_ULONG *)ptr;
	k=0;
	for(l=0; l<512; l+=2){
		m=(result[l] < 'A')?(result[l] - '0'):(result[l] - 'A' + 10);
		n=(result[l+1] < 'A')?(result[l+1] - '0'):(result[l+1] - 'A' + 10)	;
		((UCHAR *)grr->d)[k] = m*16+n;
		k++;
	}
	return 0;
}


void dump_data(BIGNUM * rr)
{
	int i=0;
	UCHAR * tmp=(UCHAR *)rr->d;
	for(i=0; i<256; i++){
		printk("%c", tmp[i]);
	}
}

int test_cav_mod_exp_function(void)
{
	int ret=0;
	BIGNUM rr;
	BIGNUM ga, gp, gm, grr;
	
	if(initParam(&ga, &gp, &gm, &grr)){
		mem_free(ga.d);
		mem_free(gp.d);
		mem_free(gm.d);
		mem_free(grr.d);
		return -1;
	}
	
	rr.d = (BN_ULONG *)mem_alloc(256);
	rr.dmax = 32;
	rr.top = 32;
	rr.flags = 0;
	rr.neg = 0;
	memset(rr.d, 0, 256);
	
	cav_mod_exp(&rr, &ga, &gp, &gm, NULL);
	if( 0 != memcmp(rr.d, grr.d, grr.top*8))
	{
		if(debuglevel){
			ret=0;
		}else{
			printk("result is not matching.\n");
			ret = -1;
		}
		//dump_data(&rr);
	}else{
		ret = 0;
	}
	mem_free(rr.d);
	mem_free(ga.d);
	mem_free(gp.d);
	mem_free(gm.d);
	mem_free(grr.d);	

	return ret;
}



