nano-dlna is a command line tool that allows you to
play a local video file in your TV (or any other DLNA compatible device)

